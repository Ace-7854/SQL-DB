﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity.Core.Mapping;
using System.Data.SQLite;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace SQLite_practice
{
    internal class Program
    {
        public const string DATABASE_FILE = "Account.sqlite";
        public static string CONNECTION_STRING = string.Format("Data Source={0};Version=3;", DATABASE_FILE);

        static void Main()
        {
            Account Current_Account = new Account();

            for (int j = 0; j <= 3; j++)
            {
                Console.Write("Connecting to Database");

                for (int i = 0; i <= 3; i++)
                {
                    Thread.Sleep(400);
                    Console.Write(".");
                }
                Console.Clear();
            }

            // CreateDatabase(); <- don't use unless db broke

            var StandardForeGroundColor = Console.ForegroundColor;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("SUCCESS");
            Console.ForegroundColor = StandardForeGroundColor;

            Thread.Sleep(400);
            Console.Clear();

            DataBaseMenu(Current_Account);

            Console.ReadKey();
        }

        /// <summary>
        /// Menu for database
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void DataBaseMenu(Account Current_Account)
        {
            int Choice;
            do
            {
                Console.WriteLine("Please Select an option using the number");
                Console.WriteLine("1.Make an account");
                Console.WriteLine("2.Access Account");
                Console.WriteLine();

            
                try
                {
                    Choice = int.Parse(Console.ReadLine());
                }
                catch (Exception)
                {
                    Console.WriteLine("Incorrect format");
                    Choice = 999;
                }

            } while ((Choice < 0) && (Choice > 3));

            switch (Choice)
            {
                case 1:
                    AccountCreate(Current_Account);
                    break;
                case 2:
                    AccountSearch(Current_Account);
                    break;
            }
        }

        /// <summary>
        /// Creates a new record for a person
        /// </summary>
        private static void AccountCreate(Account Current_Account)
        {
            Console.Clear();

            Console.WriteLine("Please enter First name");
            string FirstName = Console.ReadLine();

            Console.Clear();

            Console.WriteLine("Please enter SurName");
            string Surname = Console.ReadLine();

            Console.Clear();

            bool Valid;
            string Email;
            do
            {
                 Email = EmailValidation();



                 Valid = MatchingEmailCheck(Email, Current_Account);

            } while (!Valid);


            Console.Clear();

            string Password = PasswordValidation();

            Console.Clear();

            SQLInjectCheck(FirstName, Surname, Email, Password);

            InsertRecordIntoAccounts(FirstName, Surname, Email, Password);

            Console.WriteLine("Perfect! Account has been made!");
            Console.WriteLine("Thank you for using this service");
            Thread.Sleep(1000);
            Environment.Exit(0);

        }

        /// <summary>
        /// User enters the email and searches for the record in the database
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void AccountSearch(Account Current_Account)
        {
            bool valid;
            string Email;

            Console.WriteLine("Please enter the Email");
            Email = Console.ReadLine();
            Console.Clear();
            Current_Account = EmailVerification(Email, Current_Account);




            do
            {
                valid = SignIn(Current_Account);

            } while (!valid);

            AccountMenu(Current_Account);
        }

        /// <summary>
        /// Increases funds
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void DepositFunds(Account Current_Account)
        {
            Console.Clear();

            Console.WriteLine("Please enter the number of funds");
            int FundsIncrease = int.Parse(Console.ReadLine());

            Current_Account.Funds += FundsIncrease;

            FundsAlt(Current_Account);

            Console.WriteLine("Funds have been added!");
            Console.WriteLine("Please wait...");
            Thread.Sleep(1000);
            Console.Clear();

            AccountMenu(Current_Account);
            
        }

        /// <summary>
        /// Menu for account uses
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void AccountMenu(Account Current_Account)
        {
            Console.Clear();
            Console.WriteLine("Would you like to do anything else with your account?");
            Console.WriteLine("0.Nothing else");
            Console.WriteLine("1.Amend Account information");
            Console.WriteLine("2.View account information");
            Console.WriteLine("3.Deposit more funds");
            Console.WriteLine("4.Withdraw Funds");
            Console.WriteLine("5.Delete Account");
            Console.WriteLine();
            Console.Write("Please select a number and press enter: ");
            int Choice;

            try //prevents crash
            {
                Choice = int.Parse(Console.ReadLine());
            }
            catch (Exception)
            {
                Choice = 0;
            }

            if ((Choice > 0) && (Choice < 6))
            {
                switch (Choice)
                {
                    case 1:
                        AccountAmendments(Current_Account);
                        break;
                    case 2:
                        ViewAccount(Current_Account);
                        break;
                    case 3:
                        DepositFunds(Current_Account);
                        break;
                    case 4:
                        WithdrawFunds(Current_Account);
                        break;
                    case 5:
                        AccountDelete(Current_Account);
                        break;
                }

            }
            else
            {
                Console.WriteLine("Thank you for choosing this service!");
                Thread.Sleep(1000);
                Environment.Exit(1);
            }

        }

        /// <summary>
        /// Allows the user to change any of their information
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void AccountAmendments(Account Current_Account)
        {
            bool Valid = false;
            string choice;

            Console.WriteLine("would you like to change your email? Y/N");
            choice = Console.ReadLine();

            if (choice.ToLower() == "y")
            {
                string email;
                do
                {
                    
                     email = EmailValidation();

                    Current_Account = FindAccount(email, Current_Account);

                    Valid = MatchingEmailCheck(email, Current_Account);

                    SQLInjectCheck(email);

                } while (!Valid);
                Current_Account.Email = email;
            }

            Console.Clear();

            Console.WriteLine("would you like to change your FirstName? Y/N");
            choice = Console.ReadLine();

            if (choice.ToLower() == "y")
            {
                string name;
                
                Console.WriteLine("Please enter new Firstname");
                name = Console.ReadLine();
                    
                SQLInjectCheck(name);

                Current_Account.FirstName = name;

            }
            Console.WriteLine("would you like to change your Surname? Y/N");
            choice = Console.ReadLine();

            if (choice.ToLower() == "y")
            {
                string name;

                Console.WriteLine("Please enter new Surname");
                name = Console.ReadLine();

                SQLInjectCheck(name);

                Current_Account.Surname = name;

            }

            Console.WriteLine("would you like to change your password? Y/N");
            choice = Console.ReadLine();

            if (choice.ToLower() == "y")
            {

                string password = PasswordValidation();

                SQLInjectCheck(password);

                Current_Account.Password = password;

            }

            AccountAlt(Current_Account);

            for (int j = 0; j <= 3; j++)
            {
                Console.Write("Updating information");

                for (int i = 0; i <= 3; i++)
                {
                    Thread.Sleep(400);
                    Console.Write(".");
                }
                Console.Clear();
                AccountMenu(Current_Account);
            }
        }

        /// <summary>
        /// Deletes Account
        /// </summary>
        private static void AccountDelete(Account Current_Account)
        {
            Console.WriteLine("Are you sure you want to delete your account? Y/N");
            string Choice = Console.ReadLine();

            if (Choice.ToLower() == "y")
            {
                Console.WriteLine("Sorry to hear it!");

                Console.WriteLine("Please enter your email");
                string Email = Console.ReadLine();

                Console.WriteLine("Please enter password");
                string password = Console.ReadLine();

                if ((Current_Account.Password == password) && (Current_Account.Email == Email))
                {
                    DeleteRecord(Current_Account);
                    
                    Console.Clear();

                    for (int j = 0; j <= 3; j++)
                    {
                        Console.Write("Deleting Account");

                        for (int i = 0; i <= 3; i++)
                        {
                            Thread.Sleep(400);
                            Console.Write(".");
                        }
                        Console.Clear();
                    }
                }
                else if ((Current_Account.Password != password) && (Current_Account.Email == Email))
                {
                    Console.WriteLine("Sorry your password was wrong");
                    AccountDelete(Current_Account);
                }
                else if ((Current_Account.Password == password) && (Current_Account.Email != Email))
                {
                    Console.WriteLine("Sorry your email was wrong");
                    AccountDelete(Current_Account);
                }
            }

        }

        /// <summary>
        /// Validates password before user can use account
        /// </summary>
        /// <param name="Current_Account"></param>
        /// <returns></returns>
        private static bool SignIn(Account Current_Account)
        {
            bool valid = false;
            Console.WriteLine("Please enter password, in order to access account");
            string password = Console.ReadLine();

            if (Current_Account.Password == password)
            {
                valid = true;
            }
            else
            {
                valid = false;
            }

            return valid;
        }

        /// <summary>
        /// user can view details for the account
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void ViewAccount(Account Current_Account)
        {
            Console.Clear();

            Console.WriteLine("Email: {0}", Current_Account.Email);
            Console.WriteLine("Firstname: {0}", Current_Account.FirstName);
            Console.WriteLine("Surname: {0}", Current_Account.Surname);
            Console.WriteLine("Funds: £{0}", Current_Account.Funds);
            Console.WriteLine("");
            Console.WriteLine("Please press enter when done");
           
            Console.ReadKey();

            AccountMenu(Current_Account);

        }

        /// <summary>
        /// Checks if there is an email in use
        /// </summary>
        /// <param name="Email"></param>
        /// <param name="Current_Account"></param>
        /// <returns></returns>
        private static bool MatchingEmailCheck(string Email, Account Current_Account)
        {
            if (Email == Current_Account.Email)
            {
                Console.Clear();
                Console.WriteLine("This email is already in use!");
                Console.WriteLine("Please try again with a different email");
                return false;
            }
            else return true;
        }

        /// <summary>
        /// Withdraws funds from Account
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void WithdrawFunds(Account Current_Account)
        {
            Console.Clear();

            Console.WriteLine("Your current funds are: £{0}", Current_Account.Funds);
            Console.Write("Please enter the amount of funds you wish to withdraw: £");

            int FundsDecrease = int.Parse(Console.ReadLine());//try catch

            Current_Account.Funds -= FundsDecrease;

            FundsAlt(Current_Account);

            Console.WriteLine("Funds have been withdrawn!");
            Console.WriteLine("Please wait...");
            Thread.Sleep(1000);
            Console.Clear();

            AccountMenu(Current_Account);
        }

        #region Utility

        /// <summary>
        /// Checks for any sql injections when making an account
        /// </summary>
        /// <param name="FirstName"></param>
        /// <param name="Surname"></param>
        /// <param name="Email"></param>
        private static void SQLInjectCheck(string FirstName, string Surname, string Email, string Password)
        {
            for (int i = 0; i <= FirstName.Length - 1; i++)
            {
                if (FirstName[i] == ';')
                {
                    Console.WriteLine("Unkown item found! application closing in...");
                    Console.WriteLine("3");
                    Thread.Sleep(1000);
                    Console.WriteLine("2");
                    Thread.Sleep(1000);
                    Console.WriteLine("1");
                    Thread.Sleep(1000);
                    Environment.Exit(0);
                }
            }
            for (int i = 0; i <= Surname.Length - 1; i++)
            {
                if (Surname[i] == ';')
                {
                    Console.WriteLine("Unkown item found! application closing in...");
                    Console.WriteLine("3");
                    Thread.Sleep(1000);
                    Console.WriteLine("2");
                    Thread.Sleep(1000);
                    Console.WriteLine("1");
                    Thread.Sleep(1000);
                    Environment.Exit(0);
                }
            }
            for (int i = 0; i <= Email.Length - 1; i++)
            {
                if (Email[i] == ';')
                {
                    Console.WriteLine("Unkown item found! application closing in...");
                    Console.WriteLine("3");
                    Thread.Sleep(1000);
                    Console.WriteLine("2");
                    Thread.Sleep(1000);
                    Console.WriteLine("1");
                    Thread.Sleep(1000);
                    Environment.Exit(0);
                }
            }
            for (int i = 0; i <= Password.Length - 1; i++)
            {
                if (Password[i] == ';')
                {
                    Console.WriteLine("Unkown item found! application closing in...");
                    Console.WriteLine("3");
                    Thread.Sleep(1000);
                    Console.WriteLine("2");
                    Thread.Sleep(1000);
                    Console.WriteLine("1");
                    Thread.Sleep(1000);
                    Environment.Exit(0);
                }
            }

        }

        /// <summary>
        /// Checks for any sql injections in string
        /// </summary>
        /// <param name="strChange"></param>
        private static void SQLInjectCheck(string strChange)
        {
           
            for (int i = 0; i <= strChange.Length - 1; i++)
            {
                if (strChange[i] == ';')
                {
                    Console.WriteLine("Unkown item found! application closing in...");
                    Console.WriteLine("3");
                    Thread.Sleep(1000);
                    Console.WriteLine("2");
                    Thread.Sleep(1000);
                    Console.WriteLine("1");
                    Thread.Sleep(1000);
                    Environment.Exit(0);
                }
            }

        }

        /// <summary>
        /// Checks if email meets criteria
        /// </summary>
        /// <returns></returns>
        private static string EmailValidation()
        {
            bool ValidEmail = false;
    
            Console.WriteLine("Please enter email");
               
            String Email = Console.ReadLine();

            for (int i = 0; i <= Email.Length - 1; i++)
            {
                if (Email[i] == '@')
                {
                    ValidEmail = true;
                }
            }
       
           

            if (ValidEmail) { return Email; }
            else { return EmailValidation(); }
        }

        /// <summary>
        /// Checks if the password meets requirements
        /// </summary>
        /// <returns></returns>
        private static string PasswordValidation()
        {
            bool Caps = false;
            bool EightChar = false;
            bool Valid = false;
            string Password;

            do
            {
                Console.WriteLine("Please enter your password");
                Console.WriteLine("Your password must contain the following:");
                Console.WriteLine("- Must be a minimum of 8 Characters");
                Console.WriteLine("- Must have a capital");
                Console.Write("Password: ");
                Password = Console.ReadLine();

                for (int i = 0; i < Password.Length; i++)
                {
                    if (Password.Substring(i, 1).ToUpper() == Password.Substring(i, 1))
                    {
                        Caps = true;
                    }
                }

                if (Password.Length >= 8)
                {
                    EightChar = true;
                }

                if ((EightChar == true) && (Caps == true))
                {
                    Valid = true;
                }

            } while (!Valid);


            return Password;
        }

        #endregion

        #region SQLStatements

        /// <summary>
        /// Inserts a new account into the DB
        /// </summary>
        /// <param name="FirstName"></param>
        /// <param name="Surname"></param>
        /// <param name="Email"></param>
        private static void InsertRecordIntoAccounts(string FirstName, string Surname, string Email, string Password)
        {
            SQLiteConnection dbConnection = new SQLiteConnection(CONNECTION_STRING);
            dbConnection.Open();

            string sql = string.Format("INSERT INTO [Account] ( [ForeName], [SurName], [Email], [Password]) VALUES ( '{0}', '{1}', '{2}', '{3}' ) ", FirstName, Surname, Email, Password);
            SQLiteCommand command = new SQLiteCommand(sql, dbConnection);
            command.ExecuteNonQuery();



            dbConnection.Close();
        }

        /// <summary>
        /// This Keeps deleting the table
        /// </summary>
        private static void CreateDatabase()
        {
            SQLiteConnection.CreateFile(DATABASE_FILE);
            SQLiteConnection m_dbConnection = new SQLiteConnection(CONNECTION_STRING);
            m_dbConnection.Open();

            string sql = @"CREATE TABLE IF NOT EXISTS [Account] (
[AccountID] INTEGER NOT NULL UNIQUE,
[ForeName] TEXT NOT NULL,
[SurName] TEXT NOT NULL,
[Funds] INTEGER DEFAULT 1000,
[Email] TEXT NOT NULL,
[Password] TEXT NOT NULL,
PRIMARY KEY([AccountID] AUTOINCREMENT) )";

            SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
            command.ExecuteNonQuery();
            m_dbConnection.Close();
        }

        /// <summary>
        /// Locates the account using SELECT
        /// </summary>
        /// <param name="Email"></param>
        /// <param name="Current_Account"></param>
        /// <returns></returns>
        private static Account FindAccount(string Email, Account Current_Account)
        {
            string query = string.Format("SELECT * FROM [Account] WHERE [Email] = ('{0}');", Email);

            SQLiteConnection dbConnection = new SQLiteConnection(CONNECTION_STRING);
            SQLiteCommand command = new SQLiteCommand(query, dbConnection);
            dbConnection.Open();

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine("Email found!");
                    Current_Account.AccountID = int.Parse(reader["AccountID"].ToString());
                    Current_Account.FirstName = reader["ForeName"].ToString();//error
                    Current_Account.Surname = reader["SurName"].ToString();
                    Current_Account.Email = reader["Email"].ToString();
                    Current_Account.Funds = int.Parse(reader["Funds"].ToString());
                    Current_Account.Password = reader["Password"].ToString();

                }
            }

            dbConnection.Close(); //Close the connection to the database
            return Current_Account;
        }

        /// <summary>
        /// Deletes record
        /// </summary>
        private static void DeleteRecord(Account Current_Account)
        {
            SQLiteConnection dbConnection = new SQLiteConnection(CONNECTION_STRING);
            dbConnection.Open();

            string sql = string.Format("DELETE FROM [Account] WHERE [AccountID] = ('{0}')", Current_Account.AccountID);
            SQLiteCommand command = new SQLiteCommand(sql, dbConnection);
            command.ExecuteNonQuery();



            dbConnection.Close();
        }

        /// <summary>
        /// SQL query that amends the amount of funds
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void FundsAlt(Account Current_Account)
        {
            SQLiteConnection dbConnection = new SQLiteConnection(CONNECTION_STRING);
            dbConnection.Open();

            string query = string.Format("UPDATE [Account] SET [Funds] = ('{0}') WHERE [AccountID] = ('{1}');", Current_Account.Funds ,Current_Account.AccountID);
            SQLiteCommand command = new SQLiteCommand(query, dbConnection);
            command.ExecuteNonQuery();

            dbConnection.Close();
        }

        /// <summary>
        /// SQL query that amends record data
        /// </summary>
        /// <param name="Current_Account"></param>
        private static void AccountAlt(Account Current_Account)
        {
            SQLiteConnection dbConnection = new SQLiteConnection(CONNECTION_STRING);
            dbConnection.Open();
            //error!

            string query = string.Format("UPDATE [Account] SET [ForeName] = '{0}', [SurName] = '{1}', [Email] = '{2}', [Password] = '{3}' WHERE [AccountID] = {4};", Current_Account.FirstName, Current_Account.Surname, Current_Account.Email , Current_Account.Password, Current_Account.AccountID);
            SQLiteCommand command = new SQLiteCommand(query, dbConnection);
            command.ExecuteNonQuery();

            dbConnection.Close();
        }

        /// <summary>
        /// Locates the email and checks if the email exists
        /// </summary>
        /// <param name="Email"></param>
        /// <param name="Current_Account"></param>
        /// <returns></returns>
        private static Account EmailVerification(string Email, Account Current_Account)
        {
            string query = string.Format("SELECT * FROM [Account] WHERE [Email] = ('{0}');", Email);

            SQLiteConnection dbConnection = new SQLiteConnection(CONNECTION_STRING);
            SQLiteCommand command = new SQLiteCommand(query, dbConnection);
            dbConnection.Open();

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine("Email found!");
                    Current_Account.AccountID = int.Parse(reader["AccountID"].ToString());
                    Current_Account.FirstName = reader["ForeName"].ToString();//error
                    Current_Account.Surname = reader["SurName"].ToString();
                    Current_Account.Email = reader["Email"].ToString();
                    Current_Account.Funds = int.Parse(reader["Funds"].ToString());
                    Current_Account.Password = reader["Password"].ToString();

                }
            }
            if (Current_Account.Email == null)
            {
                Console.WriteLine("Email invalid. Re-enter your email");
                string EmailEntered = Console.ReadLine();
                FindAccount(EmailEntered, Current_Account);
            }
            Console.Clear();
            dbConnection.Close(); //Close the connection to the database
            return Current_Account;
        }
        #endregion

    }
}

public class Account
{

    public int AccountID { get; set; }

    public string FirstName { get; set; }

    public string Surname { get; set; }

    public string Email { get; set; }

    public int Funds { get; set; }

    public string Password { get; set; }
}